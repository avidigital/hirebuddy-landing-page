"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Target } from "lucide-react"

export function MissionSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const testimonials = [
    "Yay! I got the contract",
    "Thank you! HireBuddy I got the job!",
    "Thank you HireBuddy, my CV has finally been optimized",
  ]

  return (
    <section ref={sectionRef} id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gray-900">Empowering</span> <span className="text-red-500 italic">Job Seekers</span>
            <br />
            <span className="text-gray-900">with Smart Tools</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            At <span className="text-red-500 font-semibold italic">HireBuddy</span>, we believe everyone deserves the
            chance to land their dream role. That's why we built a smart, user-first platform for CV creation and
            interview preparation.
          </p>
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <div className="flex -space-x-1">
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="w-6 h-6 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full border-2 border-white"
                ></div>
              ))}
            </div>
            <span>100+ happy users</span>
          </div>
        </div>

        {/* Mission Content */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div
            className={`transition-all duration-1000 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"}`}
          >
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-8 rounded-3xl border border-blue-100">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center mr-4">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold">
                  Our <span className="text-red-500 italic">Mission</span>
                </h3>
              </div>

              <p className="text-gray-700 mb-6 text-lg leading-relaxed">
                We're on a mission to democratize access to quality interview coaching and CV optimization through
                artificial intelligence.
              </p>

              <p className="text-gray-700 text-lg leading-relaxed">
                Whether you're a fresh graduate or pivoting careers,{" "}
                <span className="text-red-500 font-semibold italic">HireBuddy</span> has the tools you need to succeed.
              </p>
            </div>
          </div>

          {/* Right Content - Success Stories */}
          <div
            className={`transition-all duration-1000 delay-600 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="grid grid-cols-3 gap-4">
              {/* Top Row */}
              <div className="col-span-3 grid grid-cols-3 gap-4 mb-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="aspect-square bg-gray-100 rounded-2xl overflow-hidden relative">
                    <Image
                      src={`/placeholder.svg?height=150&width=150&query=happy professional person ${i + 1}`}
                      alt={`Success story ${i + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>

              {/* Bottom Row */}
              <div className="col-span-3 grid grid-cols-3 gap-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i + 3} className="aspect-square bg-gray-100 rounded-2xl overflow-hidden relative">
                    <Image
                      src={`/placeholder.svg?height=150&width=150&query=successful job candidate ${i + 4}`}
                      alt={`Success story ${i + 4}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Testimonial Bubbles */}
            <div className="mt-6 space-y-3">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className={`bg-white p-3 rounded-2xl shadow-md border border-gray-100 text-sm text-gray-700 transition-all duration-500 hover:shadow-lg ${
                    index === 1 ? "ml-8" : index === 2 ? "ml-4" : ""
                  }`}
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  {testimonial}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
