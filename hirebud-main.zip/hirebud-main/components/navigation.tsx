"use client"

import type React from "react"

import { usePathname } from "next/navigation"
import Link from "next/link"

interface NavLinkProps {
  href: string
  children: React.ReactNode
  className?: string
}

export function NavLink({ href, children, className = "" }: NavLinkProps) {
  const pathname = usePathname()
  const isActive = pathname === href

  return (
    <Link
      href={href}
      className={`font-medium transition-colors ${
        isActive ? "text-gray-900 border-b-2 border-blue-600 pb-1" : "text-gray-600 hover:text-blue-600"
      } ${className}`}
    >
      {children}
    </Link>
  )
}
