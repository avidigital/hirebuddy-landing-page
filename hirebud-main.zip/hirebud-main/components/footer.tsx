import Link from "next/link"
import { Linkedin, Twitter, Facebook, Instagram } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 py-12">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-6 md:space-y-0">
          {/* Left Content */}
          <div className="space-y-4">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <div className="flex items-center">
                <span className="text-xl font-bold text-gray-900">Hire</span>
                <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
              </div>
            </Link>

            <p className="text-gray-600 max-w-md">Land Your Dream Job with AI-Powered Interview Prep & CV Tools</p>
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-4">
            <Link
              href="#"
              className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
            >
              <Linkedin className="w-5 h-5 text-gray-600" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
            >
              <Twitter className="w-5 h-5 text-gray-600" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
            >
              <Facebook className="w-5 h-5 text-gray-600" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
            >
              <Instagram className="w-5 h-5 text-gray-600" />
            </Link>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-8 pt-8 border-t border-gray-100 text-center text-gray-500 text-sm">
          <p>&copy; 2025 HireBuddy. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
