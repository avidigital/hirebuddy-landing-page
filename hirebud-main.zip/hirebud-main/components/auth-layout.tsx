"use client"

import type { ReactNode } from "react"
import Image from "next/image"
import Link from "next/link"
import { X, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"

interface AuthLayoutProps {
  children: ReactNode
  onClose?: () => void
}

export function AuthLayout({ children, onClose }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-pink-50">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="text-gray-700">
          <Menu className="w-6 h-6" />
        </Button>
        <Link href="/" className="flex items-center space-x-2">
          <div className="flex items-center">
            <span className="text-lg font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </Link>
      </div>

      {/* Desktop Logo - Make it visible */}
      <div className="hidden lg:block absolute top-6 left-6 z-50">
        <Link href="/" className="flex items-center space-x-2">
          <div className="flex items-center">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </Link>
      </div>

      {/* Main Container */}
      <div className="flex items-center justify-center p-4 lg:min-h-screen">
        <div className="w-full max-w-6xl mx-auto">
          {/* Mobile Layout */}
          <div className="lg:hidden">
            <div className="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-md mx-auto">
              {/* Video Section */}
              <div className="relative bg-gradient-to-br from-blue-500 via-purple-500 to-red-500 p-1">
                <div className="h-64 bg-gradient-to-br from-blue-500 to-red-500 rounded-t-2xl overflow-hidden relative">
                  {/* Video Content */}
                  <div className="relative h-full bg-gray-900">
                    <Image
                      src="/placeholder.svg?height=300&width=400"
                      alt="HireBuddy Interview Session"
                      fill
                      className="object-cover"
                    />

                    {/* Recording Indicator */}
                    <div className="absolute top-4 left-4 flex items-center space-x-2 bg-black/50 px-3 py-1 rounded-full">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="text-white text-sm font-medium">Recording</span>
                    </div>

                    {/* Close Button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-4 right-4 text-white hover:bg-white/20"
                      onClick={onClose}
                    >
                      <X className="w-5 h-5" />
                    </Button>

                    {/* Audio Waveform */}
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="flex items-center justify-center space-x-1 bg-black/50 px-4 py-2 rounded-full">
                        {Array.from({ length: 25 }).map((_, i) => (
                          <div
                            key={i}
                            className="w-1 bg-white rounded-full animate-pulse"
                            style={{
                              height: `${Math.random() * 16 + 4}px`,
                              animationDelay: `${i * 50}ms`,
                            }}
                          ></div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-6">{children}</div>
            </div>
          </div>

          {/* Desktop Layout */}
          <div className="hidden lg:block">
            <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
              <div className="grid lg:grid-cols-2 min-h-[600px]">
                {/* Left Side - Video Background */}
                <div className="relative bg-gradient-to-br from-blue-500 via-purple-500 to-red-500 p-1">
                  <div className="h-full bg-gradient-to-br from-blue-500 to-red-500 rounded-2xl overflow-hidden relative">
                    {/* Video Content */}
                    <div className="relative h-full bg-gray-900">
                      <Image
                        src="/placeholder.svg?height=600&width=500"
                        alt="HireBuddy Interview Session"
                        fill
                        className="object-cover"
                      />

                      {/* Recording Indicator */}
                      <div className="absolute top-4 left-4 flex items-center space-x-2 bg-black/50 px-3 py-1 rounded-full">
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                        <span className="text-white text-sm font-medium">Recording</span>
                      </div>

                      {/* Audio Waveform */}
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center justify-center space-x-1 bg-black/50 px-4 py-2 rounded-full">
                          {Array.from({ length: 30 }).map((_, i) => (
                            <div
                              key={i}
                              className="w-1 bg-white rounded-full animate-pulse"
                              style={{
                                height: `${Math.random() * 16 + 4}px`,
                                animationDelay: `${i * 50}ms`,
                              }}
                            ></div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Side - Form Content */}
                <div className="relative p-8 lg:p-12 flex flex-col justify-center">
                  {/* Close Button */}
                  {onClose && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
                      onClick={onClose}
                    >
                      <X className="w-6 h-6" />
                    </Button>
                  )}

                  {children}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
