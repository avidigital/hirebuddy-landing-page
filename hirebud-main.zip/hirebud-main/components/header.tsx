"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { NavLink } from "./navigation"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2">
          <div className="flex items-center">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink href="/">Home</NavLink>
          <NavLink href="/about">About us</NavLink>
          <NavLink href="/how-it-works">How it works</NavLink>
        </nav>

        {/* Desktop Auth Buttons */}
        <div className="hidden md:flex items-center space-x-4">
          <Link href="/login">
            <Button variant="ghost" className="text-gray-900 hover:text-blue-600">
              Log In
            </Button>
          </Link>
          <Link href="/register">
            <Button className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full">Sign Up</Button>
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <nav className="flex flex-col space-y-4 p-4">
            <NavLink href="/">Home</NavLink>
            <NavLink href="/about">About us</NavLink>
            <NavLink href="/how-it-works">How it works</NavLink>
            <div className="flex flex-col space-y-2 pt-4 border-t border-gray-100">
              <Link href="/login">
                <Button variant="ghost" className="justify-start w-full">
                  Log In
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-red-500 hover:bg-red-600 text-white w-full">Sign Up</Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
