"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { UserPlus, FileText, Download } from "lucide-react"

export function HowItWorks() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const steps = [
    {
      icon: UserPlus,
      title: "Sign Up and Choose a Tool",
      description: "Create an account and pick from our CV Builder, Interview Practice or Hot Seat sessions.",
      image: "/images/step1-signup.png",
      color: "blue",
    },
    {
      icon: FileText,
      title: "Generate your CV or start a mock interview",
      description: "Upload your CV, paste a job description, or start from scratch.",
      image: "/images/step2-interview.png",
      color: "purple",
    },
    {
      icon: Download,
      title: "Save, download, and ace your application",
      description: "Download your CV, save your sessions, or practice mock interviews until you're ready.",
      image: "/images/step3-download.png",
      color: "green",
    },
  ]

  return (
    <section ref={sectionRef} id="how-it-works" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4 lg:px-6">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            How <span className="text-red-500 italic">HireBuddy</span> Works
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Get started in minutes — no experience needed.</p>
        </div>

        {/* Steps Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`transition-all duration-1000 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${index * 200}ms` }}
            >
              <div className="bg-white rounded-3xl shadow-lg overflow-hidden h-full">
                {/* Image */}
                <div className="aspect-[4/3] bg-gray-100 relative">
                  <Image src={step.image || "/placeholder.svg"} alt={step.title} fill className="object-cover" />
                  {/* Step Icon */}
                  <div
                    className={`absolute bottom-4 right-4 w-12 h-12 bg-${step.color}-600 rounded-full flex items-center justify-center`}
                  >
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                  <p className="text-gray-600 mb-4">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
