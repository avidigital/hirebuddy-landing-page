"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { AuthLayout } from "@/components/auth-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Eye, EyeOff } from "lucide-react"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    email: "koleolarire@gmail.com",
    password: "",
    rememberMe: false,
  })
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsLoading(false)
    // Redirect to dashboard or home
    router.push("/")
  }

  return (
    <AuthLayout>
      <div className="w-full">
        {/* Logo - Mobile Only */}
        <div className="text-center mb-6 lg:mb-8 lg:hidden">
          <div className="flex items-center justify-center mb-4">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-6 lg:mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Welcome to HireBuddy</h1>
          <p className="text-gray-600 font-medium mb-2 text-sm lg:text-base">Level up your interview game.</p>
          <p className="text-gray-500 text-xs lg:text-sm">
            Sign in or create an account to generate smart, tailored CVs and practice with AI-driven interview
            questions.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                Email or Username
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 h-11 lg:h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                Password
              </Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="h-11 lg:h-12 pr-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="••••••••••••"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={formData.rememberMe}
                onCheckedChange={(checked) => setFormData({ ...formData, rememberMe: checked as boolean })}
              />
              <Label htmlFor="remember" className="text-sm text-gray-600">
                Remember Me
              </Label>
            </div>
            <Link href="/forgot-password" className="text-sm text-red-500 hover:text-red-600 font-medium">
              Forgot Password
            </Link>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-11 lg:h-12 bg-red-500 hover:bg-red-600 text-white font-medium rounded-full transition-all duration-300 hover:scale-[1.02]"
          >
            {isLoading ? "Logging in..." : "Log In"}
          </Button>

          {/* Register Link */}
          <div className="text-center">
            <span className="text-gray-600 text-sm">Don't have an account? </span>
            <Link href="/register" className="text-gray-900 font-medium hover:text-blue-600 transition-colors">
              Register
            </Link>
          </div>
        </form>
      </div>
    </AuthLayout>
  )
}
