"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { AuthLayout } from "@/components/auth-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff } from "lucide-react"

export default function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    googleEmail: "",
    aviReference: "",
    password: "",
    confirmPassword: "",
  })
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      alert("Passwords don't match!")
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsLoading(false)
    // Redirect to login or dashboard
    router.push("/login")
  }

  return (
    <AuthLayout>
      <div className="w-full">
        {/* Logo - Mobile Only */}
        <div className="text-center mb-4 lg:hidden">
          <div className="flex items-center justify-center">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-4 lg:mb-6">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
          <p className="text-gray-600 text-sm">Enter your details below to create your account</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3 lg:space-y-4">
          {/* Name Fields */}
          <div className="grid grid-cols-2 gap-3 lg:gap-4">
            <div>
              <Label htmlFor="firstName" className="text-sm font-medium text-gray-700">
                First Name
              </Label>
              <Input
                id="firstName"
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="mt-1 h-10 lg:h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-sm font-medium text-gray-700">
                Last Name
              </Label>
              <Input
                id="lastName"
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="mt-1 h-10 lg:h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-gray-700">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="mt-1 h-10 lg:h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          {/* Google Email */}
          <div>
            <Label htmlFor="googleEmail" className="text-sm font-medium text-gray-700">
              Google Email Address *
            </Label>
            <Input
              id="googleEmail"
              type="email"
              value={formData.googleEmail}
              onChange={(e) => setFormData({ ...formData, googleEmail: e.target.value })}
              className="mt-1 h-10 lg:h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Required for attending sessions via Google Meet.</p>
          </div>

          {/* AVI Reference */}
          <div>
            <Label htmlFor="aviReference" className="text-sm font-medium text-gray-700">
              AVI Reference
            </Label>
            <Input
              id="aviReference"
              type="text"
              value={formData.aviReference}
              onChange={(e) => setFormData({ ...formData, aviReference: e.target.value })}
              className="mt-1 h-10 lg:h-11 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />
            <p className="text-xs text-gray-500 mt-1">Please enter your unique AVI reference code.</p>
          </div>

          {/* Password Fields */}
          <div className="grid grid-cols-2 gap-3 lg:gap-4">
            <div>
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                Password
              </Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="h-10 lg:h-11 pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="••••••••••••"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 h-6 w-6"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>
            <div>
              <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
                Confirm Password
              </Label>
              <div className="relative mt-1">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="h-10 lg:h-11 pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="••••••••••••"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 h-6 w-6"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-11 lg:h-12 bg-red-500 hover:bg-red-600 text-white font-medium rounded-full transition-all duration-300 hover:scale-[1.02] mt-4 lg:mt-6"
          >
            {isLoading ? "Creating Account..." : "Register"}
          </Button>

          {/* Login Link */}
          <div className="text-center">
            <span className="text-gray-600 text-sm">Already have an account? </span>
            <Link href="/login" className="text-gray-900 font-medium hover:text-blue-600 transition-colors">
              Login here
            </Link>
          </div>
        </form>
      </div>
    </AuthLayout>
  )
}
