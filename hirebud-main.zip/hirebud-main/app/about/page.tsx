import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { MissionSection } from "@/components/mission-section"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <MissionSection />
      </main>
      <Footer />
    </div>
  )
}
