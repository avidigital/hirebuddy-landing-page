"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { AuthLayout } from "@/components/auth-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff } from "lucide-react"

export default function ResetPasswordPage() {
  const [showPasswords, setShowPasswords] = useState({
    new: false,
    confirm: false,
    oneTime: false,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    newPassword: "",
    confirmPassword: "",
    oneTimePassword: "",
  })
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.newPassword !== formData.confirmPassword) {
      alert("Passwords don't match!")
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsLoading(false)
    // Redirect to login
    router.push("/login")
  }

  const togglePasswordVisibility = (field: keyof typeof showPasswords) => {
    setShowPasswords((prev) => ({ ...prev, [field]: !prev[field] }))
  }

  return (
    <AuthLayout>
      <div className="w-full">
        {/* Logo - Mobile Only */}
        <div className="text-center mb-6 lg:hidden">
          <div className="flex items-center justify-center">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-6 lg:mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Reset Password</h1>
          <p className="text-gray-600 text-sm">Enter your new password below</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-6">
          {/* New Password */}
          <div>
            <Label htmlFor="newPassword" className="text-sm font-medium text-gray-700">
              New Password
            </Label>
            <div className="relative mt-1">
              <Input
                id="newPassword"
                type={showPasswords.new ? "text" : "password"}
                value={formData.newPassword}
                onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                className="h-11 lg:h-12 pr-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                placeholder="••••••••••••"
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                onClick={() => togglePasswordVisibility("new")}
              >
                {showPasswords.new ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
              Confirm Password
            </Label>
            <div className="relative mt-1">
              <Input
                id="confirmPassword"
                type={showPasswords.confirm ? "text" : "password"}
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="h-11 lg:h-12 pr-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                placeholder="••••••••••••"
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                onClick={() => togglePasswordVisibility("confirm")}
              >
                {showPasswords.confirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* One-time Password */}
          <div>
            <Label htmlFor="oneTimePassword" className="text-sm font-medium text-gray-700">
              One-time Password
            </Label>
            <div className="relative mt-1">
              <Input
                id="oneTimePassword"
                type={showPasswords.oneTime ? "text" : "password"}
                value={formData.oneTimePassword}
                onChange={(e) => setFormData({ ...formData, oneTimePassword: e.target.value })}
                className="h-11 lg:h-12 pr-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                placeholder="••••••••••••"
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                onClick={() => togglePasswordVisibility("oneTime")}
              >
                {showPasswords.oneTime ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-11 lg:h-12 bg-red-500 hover:bg-red-600 text-white font-medium rounded-full transition-all duration-300 hover:scale-[1.02]"
          >
            {isLoading ? "Resetting..." : "Reset Password"}
          </Button>

          {/* Back to Login */}
          <div className="text-center lg:hidden">
            <Link href="/login" className="text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">
              Back to Login
            </Link>
          </div>
        </form>
      </div>
    </AuthLayout>
  )
}
