"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { AuthLayout } from "@/components/auth-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsLoading(false)
    setIsSubmitted(true)

    // Redirect to reset password after 3 seconds
    setTimeout(() => {
      router.push("/reset-password")
    }, 3000)
  }

  if (isSubmitted) {
    return (
      <AuthLayout>
        <div className="w-full text-center">
          {/* Logo - Mobile Only */}
          <div className="lg:hidden flex items-center justify-center mb-6">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>

          {/* Logo - Desktop Only */}
          <div className="hidden lg:flex items-center justify-center mb-8">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4 lg:p-6">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-5 h-5 lg:w-6 lg:h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">Check Your Email</h2>
            <p className="text-gray-600 text-sm mb-4">
              We've sent a password reset link to <strong>{email}</strong>
            </p>
            <p className="text-gray-500 text-xs">Redirecting to reset password page...</p>
          </div>

          <div className="mt-6">
            <Link href="/login" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              Back to Login
            </Link>
          </div>
        </div>
      </AuthLayout>
    )
  }

  return (
    <AuthLayout>
      <div className="w-full">
        {/* Logo - Mobile Only */}
        <div className="text-center mb-6 lg:hidden">
          <div className="flex items-center justify-center">
            <span className="text-xl font-bold text-gray-900">Hire</span>
            <span className="bg-blue-500 text-white px-2 py-1 rounded text-sm font-bold ml-1">Buddy</span>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-6 lg:mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Reset Password</h1>
          <p className="text-gray-600 text-sm">Enter your email below</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-gray-700">
              Enter Email
            </Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 h-11 lg:h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              placeholder="Enter your email address"
              required
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-11 lg:h-12 bg-red-500 hover:bg-red-600 text-white font-medium rounded-full transition-all duration-300 hover:scale-[1.02]"
          >
            {isLoading ? "Sending..." : "Reset Password"}
          </Button>

          {/* Back to Login */}
          <div className="text-center lg:hidden">
            <Link href="/login" className="text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">
              Back to Login
            </Link>
          </div>
        </form>
      </div>
    </AuthLayout>
  )
}
